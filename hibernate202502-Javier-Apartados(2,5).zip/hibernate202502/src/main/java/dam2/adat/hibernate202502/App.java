package dam2.adat.hibernate202502;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import java.math.BigDecimal;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class App {
	private static Session sesion;
	private static Transaction tx;

	public static void main(String[] args) {
		// La siguiente línea elimina los mensajes informativos en consola
		Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
		SessionFactory singleton = new Configuration().configure().buildSessionFactory();
		sesion = singleton.openSession();
		tx = sesion.getTransaction();
		tx.begin();
		try {
			// Aquí nuestro código...
			
			// READ/
			/*
			Countries pais = leerPaisPorId(1); 
			System.out.println(pais);
			*/
			
			// CREATE/
			/*
			Regions region = new Regions(); region.setRegionId(1);
			region.setName("Caribbean");
			  
			Countries pais = new Countries(); 
			//pais.setCountryId(243); //Hace falta para el update 
			pais.setName("Pais hibernate 1"); 
			pais.setArea(new BigDecimal(20202020.00));
			pais.setNationalDay(java.sql.Date.valueOf("2000-10-10"));
			pais.setCountryCode2("XY"); 
			pais.setCountryCode3("PHB");
			pais.setRegions(region); 
			crearPais(pais);
			*/
			
			// UPDATE/
			/*
			Regions region = new Regions(); region.setRegionId(1);
			region.setName("Caribbean");
					 
			Countries pais = new Countries();
			pais.setCountryId(252);  
			pais.setName("Pais hibernate 2"); 
			pais.setArea(new BigDecimal(20202020.00));
			pais.setNationalDay(java.sql.Date.valueOf("2000-10-10"));
			pais.setCountryCode2("XY"); 
			pais.setCountryCode3("PHB");
			pais.setRegions(region); 
			actualizarPais(pais);
			*/
			
			//eliminarPais(250);
			
			 

			tx.commit(); // si nos hace falta...
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			sesion.close();
			singleton.close();
		}
	}

	// Metodo Read: 
	public static Countries leerPaisPorId(int id) {
		return sesion.get(Countries.class, id);
	}
	
	// Metodo Create:
	public static void crearPais(Countries pais) {
		try {
			sesion.persist(pais);
			System.out.println("Creado con exito: " + pais.getName());
		} catch (Exception e) {
			sesion.getTransaction().rollback();
			System.err.println("Error al crear el pais: " + e.getMessage());
		}
	}

	// Metodo UPDATE:
	public static void actualizarPais(Countries paisActualizado) {
		try {
			Countries pais = sesion.merge(paisActualizado);
			System.out.println("Pais actualizado o insertado con exito");
		} catch (Exception e) {
			sesion.getTransaction().rollback();
			System.err.println("Error al actualizar el pais: " + e.getMessage());			
		}
	}
		
	// Metodo DELETE
	public static void eliminarPais(int id) {
	   	try {
	    	Countries pais = sesion.find(Countries.class, id);
	    	if (pais!=null) {
	    		sesion.remove(pais);
	    		System.out.println("Pais eliminado: " + pais.getName());
	    	}else {
		   		System.out.println("No se encontro el pais " + pais.getName());
		   		sesion.getTransaction().rollback();
		   	}
	    }catch(Exception e) {
	    	sesion.getTransaction().rollback();
	    		System.out.println("Error al eliminar el pais");
	    }
	}
}