package com.ejemplo.main;

import java.util.List;

import com.ejemplo.model.Country;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class ConsultasJPQL {

	 public static void main(String[] args) {
		 
		 
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("nacionesPU");
	        
	        EntityManager em = emf.createEntityManager();

	        try {
	            // 1. Listado de todas las entidades de una tabla seleccionando solo algunos campos
	        	
	            List<Object[]> result = em.createQuery(
	                "SELECT c.name, c.area FROM Country c", Object[].class
	            ).getResultList();
	            for (Object[] row : result) {
	                System.out.println("Name: " + row[0] + ", Area: " + row[1]);
	            }

	            // 2. Listado filtrado por algún criterio (WHERE)
	            
	            
	            List<Country> result1 = em.createQuery(
	                "SELECT c FROM Country c WHERE c.area > :minArea", Country.class
	            ).setParameter("minArea", 500000).getResultList();
	            for (Country country : result1) {
	                System.out.println("Country: " + country.getName());
	            }

	            // 3. Listados ordenados por algún criterio
	            
	            List<Country> result2 = em.createQuery(
	                "SELECT c FROM Country c ORDER BY c.name ASC", Country.class
	            ).getResultList();
	            
	            
	            for (Country country : result2) {
	                System.out.println("Ordered Country: " + country.getName());
	            }

	            
	            // 4. Búsqueda de elementos por criterios exactos y aproximados
	            
	            Country exactMatch = em.createQuery(
	                "SELECT c FROM Country c WHERE c.name = :name", Country.class
	            ).setParameter("name", "España").getSingleResult();
	            System.out.println("Exact match: " + exactMatch.getName());

	            
	            List<Country> approxMatches = em.createQuery(
	                "SELECT c FROM Country c WHERE c.name LIKE :pattern", Country.class
	            ).setParameter("pattern", "%pa%").getResultList();
	            
	            for (Country country : approxMatches) {
	                System.out.println("Approx match: " + country.getName());
	            }

	            // 5. Listado de elementos con un campo numérico en un rango determinado
	            
	            List<Country> result5 = em.createQuery(
	                "SELECT c FROM Country c WHERE c.area BETWEEN :minArea AND :maxArea", Country.class
	            ).setParameter("minArea", 400000).setParameter("maxArea", 600000).getResultList();
	            
	            
	            for (Country country : result5) {
	                System.out.println("Country in range: " + country.getName());
	            }

	            
	            
	            
	            // 6. Obtención de sumas, medias, número de registros que cumplen un criterio
	            
	            
	            Long count = em.createQuery(
	                "SELECT COUNT(c) FROM Country c WHERE c.area > :minArea", Long.class
	            ).setParameter("minArea", 500000).getSingleResult();
	            System.out.println("Count: " + count);

	            
	            // 7. Algún join
	            
	            List<Object[]> result7 = em.createQuery(
	                "SELECT c.name, r.name FROM Country c JOIN c.region r", Object[].class
	            ).getResultList();
	            for (Object[] row : result7) {
	                System.out.println("Country: " + row[0] + ", Region: " + row[1]);
	            }
	            
	            
	            

	        } finally {
	            em.close();
	            emf.close();
	        }
	    }
	 }


