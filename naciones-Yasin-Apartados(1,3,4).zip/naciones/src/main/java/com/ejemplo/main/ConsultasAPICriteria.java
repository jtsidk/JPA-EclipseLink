package com.ejemplo.main;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import jakarta.persistence.criteria.*;

import com.ejemplo.model.*;

public class ConsultasAPICriteria {

	public static void main(String[] args) {
		
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("nacionesPU");
	        EntityManager em = emf.createEntityManager();
	        
	        
	        try {
	        	
	            // 1. Listado de todas las entidades de una tabla seleccionando solo algunos campos
	        	
	            CriteriaBuilder cb = em.getCriteriaBuilder();
	            CriteriaQuery<Object[]> query = cb.createQuery(Object[].class);
	            
	            Root<Country> root = query.from(Country.class);
	            query.multiselect(root.get("name"), root.get("area"));
	            

	            List<Object[]> result = em.createQuery(query).getResultList();
	            for (Object[] row : result) {
	                System.out.println("Name: " + row[0] + ", Area: " + row[1]);
	            }

	            // 2. Listado filtrado por algún criterio (WHERE)
	            
	            CriteriaQuery<Country> query1 = cb.createQuery(Country.class);
	            Root<Country> root1 = query1.from(Country.class);
	            query1.where(cb.gt(root1.get("area"), 500000));

	            List<Country> result1 = em.createQuery(query1).getResultList();
	            for (Country country : result1) {
	                System.out.println("Country: " + country.getName());
	            }

	            // 3. Listados ordenados por algún criterio
	            
	            CriteriaQuery<Country> query2 = cb.createQuery(Country.class);
	            Root<Country> root2 = query2.from(Country.class);
	            query2.orderBy(cb.asc(root2.get("name")));

	            List<Country> result2 = em.createQuery(query2).getResultList();
	            for (Country country : result2) {
	                System.out.println("Ordered Country: " + country.getName());
	            }
	            

	            // 4. Búsqueda de elementos por criterios exactos y aproximados
	            
	            
	            CriteriaQuery<Country> query3 = cb.createQuery(Country.class);
	            Root<Country> root3 = query3.from(Country.class);
	            query3.where(cb.equal(root3.get("name"), "España"));

	            Country exactMatch = em.createQuery(query3).getSingleResult();
	            System.out.println("Exact match: " + exactMatch.getName());

	            CriteriaQuery<Country> query4 = cb.createQuery(Country.class);
	            Root<Country> root4 = query4.from(Country.class);
	            query4.where(cb.like(root4.get("name"), "%pa%"));

	            
	            List<Country> approxMatches = em.createQuery(query4).getResultList();
	            for (Country country : approxMatches) {
	                System.out.println("Approx match: " + country.getName());
	            }

	            // 5. Listado de elementos con un campo numérico en un rango determinado
	            
	            
	            CriteriaQuery<Country> query5 = cb.createQuery(Country.class);
	            Root<Country> root5 = query5.from(Country.class);
	            query5.where(cb.between(root5.get("area"), 400000, 600000));

	            List<Country> result5 = em.createQuery(query5).getResultList();
	            for (Country country : result5) {
	                System.out.println("Country in range: " + country.getName());
	            }

	            // 6. Obtención de sumas, medias, número de registros que cumplen un criterio
	            
	            CriteriaQuery<Long> query6 = cb.createQuery(Long.class);
	            Root<Country> root6 = query6.from(Country.class);
	            query6.select(cb.count(root6)).where(cb.gt(root6.get("area"), 500000));

	            Long count = em.createQuery(query6).getSingleResult();
	            System.out.println("Count: " + count);

	            // 7. Algún join
	            
	            CriteriaQuery<Object[]> query7 = cb.createQuery(Object[].class);
	            Root<Country> root7 = query7.from(Country.class);
	            Join<Country, Region> join = root7.join("region");
	            
	            query7.multiselect(root7.get("name"), join.get("name"));

	            List<Object[]> result7 = em.createQuery(query7).getResultList();
	            for (Object[] row : result7) {
	                System.out.println("Country: " + row[0] + ", Region: " + row[1]);
	            }

	        } finally {
	            em.close();
	            emf.close();
	        }
	    }

	}


