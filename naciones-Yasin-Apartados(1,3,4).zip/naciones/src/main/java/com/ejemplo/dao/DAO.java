package com.ejemplo.dao;


import java.util.List;

public interface DAO<T> {
	
    void save(T entity); // Guardar una nueva entidad
    void update(T entity); // Actualizar una entidad existente
    void delete(T entity); // Eliminar una entidad
    T findById(Object id); // Buscar una entidad por su ID
    List<T> findAll(); // Listar todas las entidades
    
}