package com.ejemplo.dao;

import com.ejemplo.model.Country;
import jakarta.persistence.*;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

import java.util.List;

public class CountryDAO implements DAO<Country> {
    private final EntityManager em;

    public CountryDAO(EntityManager em) {
        this.em = em; 
    }

    @Override
    public void save(Country entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
    }

    @Override
    public void update(Country entity) {
        em.getTransaction().begin();
        em.merge(entity);
        em.getTransaction().commit();
    }

    @Override
    public void delete(Country entity) {
        em.getTransaction().begin();
        em.remove(em.contains(entity) ? entity : em.merge(entity));
        em.getTransaction().commit();
    }

    @Override
    public Country findById(Object id) {
        return em.find(Country.class, id);
    }

    @Override
    public List<Country> findAll() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Country> query = cb.createQuery(Country.class);
        Root<Country> root = query.from(Country.class);
        query.select(root);

        return em.createQuery(query).getResultList();
    }

   
}
