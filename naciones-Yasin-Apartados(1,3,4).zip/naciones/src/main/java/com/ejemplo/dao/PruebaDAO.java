package com.ejemplo.dao;

import com.ejemplo.model.Country;
import jakarta.persistence.*;

public class PruebaDAO {
	public static void main(String[] args) {
		
		
        // Crear el EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("nacionesPU");
        EntityManager em = emf.createEntityManager();

        // Crear el DAO
        CountryDAO countryDAO = new CountryDAO(em);

        try {
            // Guardar un nuevo país
            Country spain = new Country();
            spain.setName("España");
            spain.setArea(505944.0);
            spain.setCountryCode2("ES2");
            spain.setCountryCode3("ESP2");
            
            //probamos el metodo save del DAO
            countryDAO.save(spain);
            System.out.println("País guardado: " + spain.getName());

            // Buscar el país por su ID
            Country foundCountry = countryDAO.findById(spain.getCountryId());
            System.out.println("País encontrado: " + foundCountry.getName());

        } finally {
            em.close();
            emf.close();
        }
    }
}
